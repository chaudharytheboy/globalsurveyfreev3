<?php
$con=mysqli_connect("localhost","root","","free2");
$eid=$_REQUEST['eid'];
mysqli_query($con,"delete from `products` where `id`='$eid'");
echo "<script>top.window.location.href='dashboard.php';</script>";
?>